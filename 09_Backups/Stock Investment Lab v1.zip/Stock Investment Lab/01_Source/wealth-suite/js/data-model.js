/* ============================================================================
   Wealth Intelligence Suite — Shared Data Model
   ============================================================================
   This is the single source of truth every module reads and writes. It maps
   directly onto the approved database schema (schema.sql, approved this
   session) — same entities, same relationships, just JS objects instead of
   SQL rows since the project moved to a pure HTML/CSS/JS architecture.

   Permanent rule: no module ever holds its own private copy of this data.
   Every module reads from window.WealthData and writes back through the
   setters below, then calls persistData() to save. This is what makes
   "enter once, every module sees it" literally true — there is only one
   copy, in memory, shared by reference.
============================================================================ */

const WealthData = (function () {

  function emptyState() {
    return {
      // securities: master ticker list, everything else references this
      securities: {
        // ticker: { displayName, sector, capCategory, isBank, indexMember, active }
      },

      // fundamentals: one entry per ticker, latest snapshot (matches
      // fundamentals_snapshot table — years[], qualitative{}, etc.)
      fundamentals: {
        // ticker: { years: [...], qualitative: {...}, auditorLog: [...],
        //           quarters: [...], fetchedAt, source }
      },

      // holdings: your actual portfolio (matches holdings table)
      holdings: [
        // { id, ticker, quantity, avgCost, purchaseDate, assetClass,
        //   liquidityTier, active, notes }
      ],

      // watchlist: stocks under consideration, separate from actual holdings
      // (approved refinement — this table did not exist in the original plan)
      watchlist: [
        // { id, ticker, category: 'Watch'|'Research'|'Buy Soon'|'Reject',
        //   notes, targetPrice, dateAdded, dateUpdated }
      ],

      // researchLibrary: documents + AI analysis (renamed from research_notes
      // per approved refinement — this will hold more than just notes)
      researchLibrary: [
        // { id, ticker, docType, title, content, aiAnalysis, sourceUrl, addedAt }
      ],

      // intradayTrades: the satellite allocation's discipline log — not a
      // signal generator (see intraday-scope-decision.md), a rules-checklist
      // and trade record.
      intradayTrades: [
        // { id, ticker, entryPrice, stopLoss, target, positionSize,
        //   checklistPassed: {sizing, stopSet, riskReward, reasonStated},
        //   status: 'Open'|'Closed-Win'|'Closed-Loss', pnl, notes, dateOpened, dateClosed }
      ],

      // macroIndicators: time series of India macro data
      macroIndicators: {
        // indicatorKey: [ { date, value, source }, ... ]
      },

      // settings: global assumptions used across modules (approved refinement)
      settings: {
        defaultRiskPct: 1.0,
        dcfGrowthRate: 10,
        dcfDiscountRate: 12,
        riskFreeRate: 7.0,
        marginOfSafety: 20,
        sipMonthlyAmount: 100000,
        targetEquityAllocationPct: 70,
        intradaySatelliteAllocationPct: 15,
        minRiskRewardRatio: 2.0
      },

      // priceCache: latest known price per ticker (kept deliberately simple —
      // this is NOT full OHLCV history; that stays out of scope for the
      // browser-only architecture until/unless a real need justifies it,
      // per the "no rewrite for purity" rule — don't build infrastructure
      // ahead of an actual, present need)
      priceCache: {
        // ticker: { price, asOf }
      },

      // meta: bookkeeping about the data itself, not the data
      meta: {
        schemaVersion: 2,
        lastSavedAt: null
      }
    };
  }

  // The live, in-memory state. Exactly one instance, shared by reference —
  // this IS the "shared JavaScript data model" the project now requires.
  let state = emptyState();

  return {
    // ---- Read access ----
    get: () => state,
    getSecurity: (ticker) => state.securities[ticker],
    getFundamentals: (ticker) => state.fundamentals[ticker],
    getHoldings: () => state.holdings,
    getWatchlist: () => state.watchlist,
    getResearchLibrary: () => state.researchLibrary,
    getSetting: (key) => state.settings[key],
    getAllSettings: () => state.settings,

    // ---- Write access — always through these, never direct mutation from
    // a module, so there is exactly one place that changes shape, ever ----
    upsertSecurity(ticker, data) {
      state.securities[ticker] = { ...state.securities[ticker], ...data, ticker };
    },
    upsertFundamentals(ticker, data) {
      state.fundamentals[ticker] = data;
    },
    addHolding(holding) {
      const id = Date.now() + Math.random();
      state.holdings.push({ id, active: true, ...holding });
      return id;
    },
    removeHolding(id) {
      state.holdings = state.holdings.filter(h => h.id !== id);
    },
    addWatchlistItem(item) {
      const id = Date.now() + Math.random();
      state.watchlist.push({ id, dateAdded: new Date().toISOString(), ...item });
      return id;
    },
    removeWatchlistItem(id) {
      state.watchlist = state.watchlist.filter(w => w.id !== id);
    },
    addResearchNote(note) {
      const id = Date.now() + Math.random();
      state.researchLibrary.push({ id, addedAt: new Date().toISOString(), ...note });
      return id;
    },
    getIntradayTrades: () => state.intradayTrades,
    addIntradayTrade(trade) {
      const id = Date.now() + Math.random();
      state.intradayTrades.push({ id, dateOpened: new Date().toISOString(), status: "Open", ...trade });
      return id;
    },
    updateIntradayTrade(id, updates) {
      const trade = state.intradayTrades.find(t => t.id === id);
      if (trade) Object.assign(trade, updates);
    },
    removeIntradayTrade(id) {
      state.intradayTrades = state.intradayTrades.filter(t => t.id !== id);
    },
    updateSetting(key, value) {
      state.settings[key] = value;
    },

    // ---- Whole-state operations, used by the persistence layer ----
    replaceAll(newState) {
      // Merge onto emptyState() so an older exported file missing newer
      // fields (e.g. a future schema addition) doesn't crash the app —
      // missing keys fall back to sane defaults instead of undefined.
      state = { ...emptyState(), ...newState };
    },
    reset() {
      state = emptyState();
    }
  };
})();
